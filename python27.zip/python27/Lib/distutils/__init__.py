"""distutils

The main package for the Python Module Distribution Utilities.  Normally
used from a setup script as

   from distutils.core import setup

   setup (...)
"""

__revision__ = "$Id: __init__.py 82500 2010-07-03 13:56:13Z benjamin.peterson $"

# Distutils version
#
# Updated automatically by the Python release process.
#
#--start constants--
__version__ = "2.7"
#--end constants--
